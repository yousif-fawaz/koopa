chmod 000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game*
iptables -I OUTPUT -p tcp  --dport 8082 -j DROP
iptables -I OUTPUT -p tcp  --dport 8086 -j DROP
iptables -I OUTPUT -p tcp  --dport 17000 -j DROP
iptables -I INPUT -p tcp  --dport 17000 -j DROP
iptables -I OUTPUT -p tcp  --dport 17500 -j DROP
iptables -I INPUT -p tcp  --dport 17500 -j DROP
iptables -I OUTPUT -p tcp  --dport 20001 -j DROP
iptables -I OUTPUT -p tcp  --dport 20002 -j DROP
iptables -I OUTPUT -p tcp  --dport 20371 -j DROP
iptables -L -n -v dpt:17500