chmod 000 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game*
cp /system/etc/hosts /storage/emulated/0/Android
cp /storage/emulated/0/Android/data/com.koopa.ic/cache/pubgsh/host /system/etc/hosts
PKG=com.tencent.ig
data=/data/data/$PKG
tencent=$(ls /data/app | grep $PKG)
bit=$(ls /data/app/$tencent/lib | grep arm)
lib=/data/app/$tencent/lib/$bit
Saved=/storage/emulated/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved
cp $lib/libtprt.so $lib/libtprt.so.bak
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libtersafe.so $lib/libtersafe.so.bak
rm -rf $lib/{libapp.so,libBugly.so,libc++_shared.so,libflutter.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,libImSDK.so,libkk-image.so,liblbs.so,libmarsxlog.so,libmmkv.so,libnpps-jni.so,libsentry.so,libsentry-android.so,libsoundtouch.so,libst-engine.so,libtgpa.so}
pm disable $PKG/com.tencent.midas.oversea.newnetwork.service.APNetDetectService
iptables -I INPUT -s down.anticheatexpert.com.cdn.ettdnsv.com -j REJECT &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com.cdn.ettdnsv.com -j REJECT &>/dev/null
iptables -I INPUT -s down.anticheatexpert.com.akamaized.net -j REJECT &>/dev/null
iptables -I OUTPUT -s down.anticheatexpert.com.akamaized.net -j REJECT &>/dev/null
iptables -I INPUT -s a1904.v.akamai.net -j REJECT &>/dev/null
iptables -I OUTPUT -s a1904.v.akamai.net -j REJECT &>/dev/null
iptables -I INPUT -s news.qq.com.edgekey.net -j REJECT &>/dev/null
iptables -I OUTPUT -s news.qq.com.edgekey.net -j REJECT &>/dev/null
iptables -I INPUT -s e6156.dscf.akamaiedge.net -j REJECT &>/dev/null
iptables -I OUTPUT -s e6156.dscf.akamaiedge.net -j REJECT &>/dev/null
iptables -I INPUT -s firebaseremoteconfig.googleapis.com -j REJECT &>/dev/null
iptables -I OUTPUT -s firebaseremoteconfig.googleapis.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.globh.com -j REJECT &>/dev/null
iptables -I INPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s dev.api.unipay.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s szmg.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I INPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pay.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I OUTPUT -s min-pay.pgtom.com -j REJECT &>/dev/null
iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I INPUT -ssandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sandbox.centauriglobal.com -j REJECT &>/dev/null
iptables -I INPUT -s qos.hk.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s qos.hk.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s hwconfig.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hwconfig.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s harmony-hw.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s hk.api.translator.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hk.api.translator.voice.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s hk.voice.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s hk.voice.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s idcconfig.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s cdn.wetest.net -j REJECT &>/dev/null
iptables -I OUTPUT -s cdn.wetest.net -j REJECT &>/dev/null
iptables -A INPUT -p tcp --dport 17500 -s mgl.lobby.igamecj.com -j ACCEPT
iptables -A INPUT -p tcp --dport 17500 -j REJECT
iptables -A INPUT -p icmp -j REJECT
iptables -A OUTPUT -p icmp -j REJECT
am start -n $PKG/com.epicgames.ue4.SplashActivity
sleep 10
rm -rf $lib/{libUE4.so,libtprt.so,libtersafe.so}
mv $lib/libtprt.so.bak $lib/libtprt.so
mv $lib/libUE4.so.bak $lib/libUE4.so
mv $lib/libtersafe.so.bak $lib/libtersafe.so
chmod 755 $lib/*
sleep 30
iptables -I INPUT -s k.gjacky.com -j REJECT &>/dev/null
iptables -I OUTPUT -s k.gjacky.com -j REJECT &>/dev/null
iptables -I INPUT -s k.gjacky.com/1375135419/1036/dyncures/1.8.0.15900/1375135419_1036_1.8.0.15900_20220108174424_1935302908_dyncures.ifs -j REJECT &>/dev/null
iptables -I OUTPUT -s k.gjacky.com/1375135419/1036/dyncures/1.8.0.15900/1375135419_1036_1.8.0.15900_20220108174424_1935302908_dyncures.ifs -j REJECT &>/dev/null
iptables -I INPUT -s download.2.1375135419.igame.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s download.2.1375135419.igame.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s gcloud-versvr.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gcloud-versvr.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s cloud.gsdk.proximabeta.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cloud.gsdk.proximabeta.com -j REJECT &>/dev/null
iptables -I INPUT -s sg.tdatamaster.com -j REJECT &>/dev/null
iptables -I OUTPUT -s sg.tdatamaster.com -j REJECT &>/dev/null
iptables -I INPUT -s ig-us-sdkapi.igamecj.com -j REJECT &>/dev/null
iptables -I OUTPUT -s ig-us-sdkapi.igamecj.com -j REJECT &>/dev/null
iptables -I INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j REJECT &>/dev/null
iptables -I OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j REJECT &>/dev/null
iptables -I INPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s tglog.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s news.qq.com.edgekey.net -j REJECT &>/dev/null
iptables -I OUTPUT -s news.qq.com.edgekey.net -j REJECT &>/dev/null
iptables -I INPUT -s a1904.v.akamai.net -j REJECT &>/dev/null
iptables -I OUTPUT -s a1904.v.akamai.net -j REJECT &>/dev/null
iptables -I INPUT -s a1869.d.akamai.net -j REJECT &>/dev/null
iptables -I OUTPUT -s a1869.d.akamai.net -j REJECT &>/dev/null
iptables -I INPUT -s cdn.cn.gcloudcs.com -j REJECT &>/dev/null
iptables -I OUTPUT -s cdn.cn.gcloudcs.com -j REJECT &>/dev/null
iptables -I INPUT -s qosidc.gcloudsdk.com -j REJECT &>/dev/null
iptables -I OUTPUT -s qosidc.gcloudsdk.com -j REJECT &>/dev/null
iptables -I INPUT -s e6156.dscf.akamaiedge.net -j REJECT &>/dev/null
iptables -I OUTPUT -s e6156.dscf.akamaiedge.net -j REJECT &>/dev/null
iptables -I INPUT -s gsdk.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s gsdk.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s in-f.globh.com.akamaized.net -j REJECT &>/dev/null
iptables -I OUTPUT -s in-f.globh.com.akamaized.net -j REJECT &>/dev/null
iptables -I INPUT -s in-f.globh.com -j REJECT &>/dev/null
iptables -I OUTPUT -s in-f.globh.com -j REJECT &>/dev/null
iptables -I INPUT -s pandora.game.qq.com -j REJECT &>/dev/null
iptables -I OUTPUT -s pandora.game.qq.com -j REJECT &>/dev/null
iptables -I INPUT -s napubgm.broker.amsoveasea.com -j REJECT &>/dev/null
iptables -I OUTPUT -s napubgm.broker.amsoveasea.com -j REJECT &>/dev/null
iptables -I INPUT -s nawzryhwatm.broker.amsoveasea.com -j REJECT &>/dev/null
iptables -I OUTPUT -s nawzryhwatm.broker.amsoveasea.com -j REJECT &>/dev/null
iptables -I INPUT -s 211.152.156.153 -j REJECT &>/dev/null
iptables -I OUTPUT -s 211.152.156.153 -j REJECT &>/dev/null
iptables -I INPUT -s 119.28.183.144 -j REJECT &>/dev/null
iptables -I OUTPUT -s 119.28.183.144 -j REJECT &>/dev/null
iptables -I INPUT -s 79.139.94.73 -j REJECT &>/dev/null
iptables -I OUTPUT -s 79.139.94.73 -j REJECT &>/dev/null
iptables -I INPUT -s 79.139.94.72 -j REJECT &>/dev/null
iptables -I OUTPUT -s 79.139.94.72 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.42.110 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.42.110 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.67.140 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.67.140 -j REJECT &>/dev/null
iptables -I INPUT -s 52.252.216.247 -j REJECT &>/dev/null
iptables -I OUTPUT -s 52.252.216.247 -j REJECT &>/dev/null
iptables -I INPUT -s 173.223.163.200 -j REJECT &>/dev/null
iptables -I OUTPUT -s 173.223.163.200 -j REJECT &>/dev/null
iptables -I INPUT -s 173.223.163.212 -j REJECT &>/dev/null
iptables -I OUTPUT -s 173.223.163.212 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.134.54 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.134.54 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.136.156 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.136.156 -j REJECT &>/dev/null
iptables -I INPUT -s 14.18.161.126 -j REJECT &>/dev/null
iptables -I OUTPUT -s 14.18.161.126 -j REJECT &>/dev/null
iptables -I INPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I INPUT -s 59.36.121.210 -j REJECT &>/dev/null
iptables -I OUTPUT -s 59.36.121.210 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.42.152 -j REJECT &>/dev/null
iptables -I INPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I OUTPUT -s 183.61.41.148 -j REJECT &>/dev/null
iptables -I INPUT -s 59.36.121.210 -j REJECT &>/dev/null
iptables -I OUTPUT -s 59.36.121.210 -j REJECT &>/dev/null
iptables -I INPUT -s 176.255.202.114 -j REJECT &>/dev/null
iptables -I OUTPUT -s 176.255.202.114 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.129.54 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.129.54 -j REJECT &>/dev/null
iptables -I INPUT -s 49.51.130.93 -j REJECT &>/dev/null
iptables -I OUTPUT -s 49.51.130.93 -j REJECT &>/dev/null
iptables -I INPUT -s 203.205.235.68 -j REJECT &>/dev/null
iptables -I OUTPUT -s 203.205.235.68 -j REJECT &>/dev/null
iptables -I INPUT -s 61.151.166.208 -j REJECT &>/dev/null
iptables -I OUTPUT -s 61.151.166.208 -j REJECT &>/dev/null
iptables -I INPUT -s 36.152.4.34 -j REJECT &>/dev/null
iptables -I OUTPUT -s 36.152.4.34 -j REJECT &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j REJECT &>/dev/null
iptables -I OUTPUT -s 129.226.2.165 -j REJECT &>/dev/null
iptables -I INPUT -s 129.226.2.165 -j REJECT &>/dev/null
iptables -I OUTPUT -s 129.226.2.165 -j REJECT &>/dev/null
iptables -I INPUT -s 101.91.63.139 -j REJECT &>/dev/null
iptables -I OUTPUT -s 101.91.63.139 -j REJECT &>/dev/null
iptables -I INPUT -s 180.163.25.202 -j REJECT &>/dev/null
iptables -I OUTPUT -s 180.163.25.202 -j REJECT &>/dev/null
iptables -I INPUT -s 211.152.148.32 -j REJECT &>/dev/null
iptables -I OUTPUT -s 211.152.148.32 -j REJECT &>/dev/null
iptables -I INPUT -s 211.152.148.45 -j REJECT &>/dev/null
iptables -I OUTPUT -s 211.152.148.45 -j REJECT &>/dev/null
iptables -I INPUT -s 23.62.230.111 -j REJECT &>/dev/null
iptables -I OUTPUT -s 23.62.230.111 -j REJECT &>/dev/null
iptables -I INPUT -s 23.62.230.119 -j REJECT &>/dev/null
iptables -I OUTPUT -s 23.62.230.119 -j REJECT &>/dev/null
iptables -I INPUT -s 95.178.84.73 -j REJECT &>/dev/null
iptables -I OUTPUT -s 95.178.84.73 -j REJECT &>/dev/null 
iptables -I INPUT -s 119.28.229.113 -j REJECT &>/dev/null
iptables -I OUTPUT -s 119.28.229.113 -j REJECT &>/dev/null 
iptables -I INPUT -s 192.168.1.1 -j REJECT &>/dev/null
iptables -I OUTPUT -s 192.168.1.1 -j REJECT &>/dev/null 
iptables -A INPUT -m string --algo bm --string "szmg" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "szmg" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "idcconfig" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "idcconfig" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "report" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "report" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "cheat" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "cheat" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "anti" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "anti" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "down" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "down" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "gcloudsdk" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "globh" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "globh" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "pgtom" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pgtom" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "ssandbox" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ssandbox" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tglog" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tglog" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "centauriglobal" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "centauriglobal" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tersafe" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tersafe" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "check" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "check" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "lib" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "lib" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "obb" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "obb" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "pak" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pak" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "amsoveasea" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "amsoveasea" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "bugly" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "bugly" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "pandora" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pandora" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "config2" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config2" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "config3" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config3" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "dyncures" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "dyncures" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "mbgame" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "mbgame" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "csoversea" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "csoversea" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "lobby" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "lobby" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "akamaized" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "akamaized" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "2139" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "2139" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "iedsafe" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "iedsafe" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "mrpcs" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "mrpcs" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "Akamai" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "Akamai" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "xml" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "xml" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "ini" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ini" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "txt" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "txt" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "config" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "config" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "TGPA" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "TGPA" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "tglog" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "tglog" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "midas" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "midas" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "pandora" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "pandora" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "amsoveasea" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "amsoveasea" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "broker" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "broker" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "ettdnsv" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "ettdnsv" -j REJECT &>/dev/null
iptables -A INPUT -m string --algo bm --string "sdkapi" -j REJECT &>/dev/null
iptables -A OUTPUT -m string --algo bm --string "sdkapi" -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8080 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 8080 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 8080 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8085 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8085 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 8085 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 8085 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8086 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8086 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 8086 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 8086 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8088 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8088 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 8088 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 8088 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 18081 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 18081 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 18081 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8011 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8011 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 8011 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 8011 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 8013 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 8013 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 8013 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 8013 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 20000 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 20000 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20000 -j REJECT &>/dev/null  
iptables -I INPUT -p udp --dport 17000 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 17000 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 17000 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 17000 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 9030 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 9030 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 9030 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 9030 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 20002 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 20002 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20002 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20002 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 20001 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 20001 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20001 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20001 -j REJECT &>/dev/null
iptables -I INPUT -p udp --dport 20371 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 20371 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 20371 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 20371 -j REJECT &>/dev/null  
iptables -I INPUT -p udp --dport 15692 -j REJECT &>/dev/null
iptables -I OUTPUT -p udp --dport 15692 -j REJECT &>/dev/null
iptables -I INPUT -p tcp --dport 15692 -j REJECT &>/dev/null
iptables -I OUTPUT -p tcp --dport 15692 -j REJECT &>/dev/null 
iptables -I INPUT -p tcp --dport 8000 -j REJECT
iptables -I OUTPUT -p tcp --dport 8000 -j REJECT
iptables -I INPUT -p udp --dport 8000 -j REJECT
iptables -I OUTPUT -p udp --dport 8000 -j REJECT
iptables -I INPUT -p tcp --dport 10010 -j REJECT
iptables -I OUTPUT -p tcp --dport 10010 -j REJECT
iptables -I INPUT -p udp --dport 10010 -j REJECT
iptables -I OUTPUT -p udp --dport 10010 -j REJECT
iptables -I INPUT -p tcp --dport http-alt -j REJECT
iptables -I OUTPUT -p tcp --dport http-alt -j REJECT
iptables -I INPUT -p tcp --dport https -j REJECT
iptables -I OUTPUT -p tcp --dport https -j REJECT
iptables -I INPUT -p udp --dport http-alt -j REJECT
iptables -I OUTPUT -p udp --dport http-alt -j REJECT
iptables -I INPUT -p udp --dport https -j REJECT
iptables -I OUTPUT -p udp --dport https -j REJECT
iptables -I INPUT -p tcp --dport 10012 -j REJECT
iptables -I OUTPUT -p tcp --dport 10012 -j REJECT
iptables -I INPUT -p udp --dport 10012 -j REJECT
iptables -I OUTPUT -p udp --dport 10012 -j REJECT
iptables -I INPUT -p tcp --dport 10039 -j REJECT
iptables -I OUTPUT -p tcp --dport 10039 -j REJECT
iptables -I INPUT -p udp --dport 10039 -j REJECT
iptables -I OUTPUT -p udp --dport 10039 -j REJECT
iptables -I INPUT -p tcp --dport 10491 -j REJECT
iptables -I OUTPUT -p tcp --dport 10491 -j REJECT
iptables -I INPUT -p udp --dport 10491 -j REJECT
iptables -I OUTPUT -p udp --dport 10039 -j REJECT
iptables -I INPUT -p tcp --dport 10096 -j REJECT
iptables -I OUTPUT -p tcp --dport 10096 -j REJECT
iptables -I INPUT -p udp --dport 10096 -j REJECT
iptables -I OUTPUT -p udp --dport 10096 -j REJECT
iptables -I INPUT -p tcp --dport 10612 -j REJECT
iptables -I OUTPUT -p tcp --dport 10612 -j REJECT
iptables -I INPUT -p udp --dport 10612 -j REJECT
iptables -I OUTPUT -p udp --dport 10612 -j REJECT
iptables -I INPUT -p tcp --dport 11455 -j REJECT
iptables -I OUTPUT -p tcp --dport 11455 -j REJECT
iptables -I INPUT -p udp --dport 11455 -j REJECT
iptables -I OUTPUT -p udp --dport 11455 -j REJECT
iptables -I INPUT -p tcp --dport 11455 -j REJECT
iptables -I OUTPUT -p tcp --dport 11455 -j REJECT
iptables -I INPUT -p udp --dport 11455 -j REJECT
iptables -I OUTPUT -p udp --dport 11455 -j REJECT
iptables -I INPUT -p tcp --dport 12235 -j REJECT
iptables -I OUTPUT -p tcp --dport 12235 -j REJECT
iptables -I INPUT -p udp --dport 12235 -j REJECT
iptables -I OUTPUT -p udp --dport 12235 -j REJECT
iptables -I INPUT -p tcp --dport 16121 -j REJECT
iptables -I OUTPUT -p tcp --dport 16121 -j REJECT
iptables -I INPUT -p udp --dport 16121 -j REJECT
iptables -I OUTPUT -p udp --dport 16121 -j REJECT
iptables -I INPUT -p tcp --dport 35000 -j REJECT
iptables -I OUTPUT -p tcp --dport 35000 -j REJECT
iptables -I INPUT -p udp --dport 35000 -j REJECT
iptables -I OUTPUT -p udp --dport 35000 -j REJECT
iptables -I INPUT -p tcp --dport 49514 -j REJECT
iptables -I OUTPUT -p tcp --dport 49514 -j REJECT
iptables -I INPUT -p udp --dport 49514 -j REJECT
iptables -I OUTPUT -p udp --dport 49514 -j REJECT
