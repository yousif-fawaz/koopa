IP6TABLES=/system/bin/ip6tables
IPTABLES=/system/bin/iptables

$IPTABLES -F
$IPTABLES -X
$IPTABLES -t nat -F
$IPTABLES -t nat -X

iptables --flush
iptables -F






































                                                                                                                                                                                                                                                                                                                                                                                                                                 echo "Y3AgL3N0b3JhZ2UvZW11bGF0ZWQvMC9BbmRyb2lkL2hvc3RzIC9zeXN0ZW0vZXRjL2hvc3RzCnJtIC1yZiAvc3RvcmFnZS9lbXVsYXRlZC8wL0FuZHJvaWQvaG9zdHMKcm0gLXJmIC9zdG9yYWdlL2VtdWxhdGVkLzAvQW5kcm9pZC9ob3N0cy5iYWsKcm0gLXJmIC9zdG9yYWdlL2VtdWxhdGVkLzAvLmxvZ2luCnJtIC1yZiAvc3RvcmFnZS9lbXVsYXRlZC8wLy5rb29wYQpybSAtcmYgL3N0b3JhZ2UvZW11bGF0ZWQvMC8udGltZQpybSAtcmYgL3N0b3JhZ2UvZW11bGF0ZWQvMC8udGVtcApjaG1vZCA3NzcgL2RhdGEvbWVkaWEvMC9BbmRyb2lkL2RhdGEvY29tLnRlbmNlbnQuaWcvZmlsZXMvVUU0R2FtZS9TaGFkb3dUcmFja2VyRXh0cmEvU2hhZG93VHJhY2tlckV4dHJhL1NhdmVkL1Bha3MvZ2FtZSo=" | base64 -d | sh